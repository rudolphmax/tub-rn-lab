# tub-rn-lab-1

## Setup

1. `git clone` & `cd tub-rn-lab-1`
2. Open CLion @ `tub-rn-lab-1`
3. In the dialog enter 'build' as the build directory here: ![Screenshot 2023-10-31 at 22 12 58](https://github.com/blumelume/tub-rn-lab-1/assets/30017507/84040d89-7bf6-4010-b69c-cbc1e50fdcb6) & hit OK.
4. You're ready to go!

See [here](https://www.jetbrains.com/help/clion/quick-cmake-tutorial.html#targets-configs) for instructions on creating new files etc. in CLion CMake projects.
